import os
import cv2
import json
import numpy as np
import random
import logging
import time

logging.basicConfig(
    format="%(asctime)s %(message)s",
    datefmt="%Y-%m-%d,%H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


##change all paths to /home/jovyan/...


#DATASETS_PATH = '/home/jovyan/input'

#os.makedirs('/home/jovyan/output',exist_ok=True)
#output_path = '/home/jovyan/output'

DATASETS_PATH = 'input'

os.makedirs('output',exist_ok=True)
output_path = 'output'


htr_images_path = os.path.join(DATASETS_PATH,'HTR/images/')
od_images_path = os.path.join(DATASETS_PATH,'zsOD/images/')
vqa_images_path = os.path.join(DATASETS_PATH,'VQA/images/')

od_requests_path = os.path.join(DATASETS_PATH,'zsOD/requests.json')
questions_path = os.path.join(DATASETS_PATH,'VQA/questions.json')
c2c_requests_path = os.path.join(DATASETS_PATH,'C2C/requests.json')

def dummy_model(content, task_name):
    if task_name =='HTR':
        return 'в'
    elif task_name == 'zsOD':
        empty = []
        random_box = [[0,0,100,100],[50,50,200,200]]
        return random.choice([empty,random_box])
    elif task_name == 'VQA':
        return 'yes'
    elif task_name == 'C2C':
        return "def find ( x , par ) : NEW_LINE INDENT if par [ x ] == x : ..."


if __name__ == "__main__":
    t_all_start = time.time()

    logger.info(f"Start HTR")
    t_start = time.time()
    ###HTR###
    pred_dict_htr = {}
    for file in os.listdir(htr_images_path):
        file_name = os.path.join(htr_images_path,file)
        img = cv2.imread(file_name)
        # Предсказание - строка, результат перевода текста на изображении с помощью модели
        prediction = dummy_model(img,'HTR')
        pred_dict_htr[file] = prediction
    with open(os.path.join(output_path,'prediction_HTR.json'), 'w') as outfile:
        json.dump(pred_dict_htr, outfile)
    t_end = time.time()
    logger.info(f"Processing time HTR: {t_end - t_start}")
    ###zsOD###
    logger.info(f"Start zsOD")
    t_start = time.time()

    with open(od_requests_path) as f:
        od_requests = json.load(f)
    pred_dict_od = {}

    for file in os.listdir(od_images_path):
        file_name = os.path.join(od_images_path,file)
        img = cv2.imread(file_name)
        curr_request = od_requests[file]
        # Предсказание - словарь, с ключами - классами, и значениями - детектированными боксами
        pred_dict_od[file] = {}
        for label in curr_request:
            prediction = dummy_model((img,label),'zsOD')
            pred_dict_od[file][label] = prediction
            
    with open(os.path.join(output_path,'prediction_zsOD.json'), 'w') as outfile:
        json.dump(pred_dict_od, outfile)
    t_end = time.time()
    logger.info(f"Processing time zsOD: {t_end - t_start}")
    ###VQA###
    logger.info(f"Start VQA")
    t_start = time.time()

    with open(questions_path) as f:
        questions = json.load(f)
    pred_dict_vqa = {}


    #Вопросов больше чем изображений
    processed_images = {}

    for ques_id in questions:
        question = questions[ques_id]
        file_name = os.path.join(vqa_images_path,question['file_name'])
        if file_name not in processed_images:
            img = cv2.imread(file_name)
            processed_images[file_name] = img
        else:
            img = processed_images[file_name]


        curr_question = question['question']

        # Предсказание - словарь, с ключами - id запросами, и значениями - ответом на вопрос
        prediction = dummy_model((img,curr_question),'VQA')

        pred_dict_vqa[ques_id] = prediction    
    with open(os.path.join(output_path,'prediction_VQA.json'), 'w') as outfile:
        json.dump(pred_dict_vqa, outfile)
    t_end = time.time()
    logger.info(f"Processing time VQA: {t_end - t_start}")
    ###C2C###
    logger.info(f"Start C2C")
    t_start = time.time()
    with open(c2c_requests_path) as f:
        c2c_requests = json.load(f)
    
    pred_dict_c2c = {}

    for req_id in c2c_requests:
        request = c2c_requests[req_id]

        # Предсказание - текстовая строка, которая является переводом функций/программ на язык Python
        prediction = dummy_model(request,'C2C')
        pred_dict_c2c[req_id] = prediction
    with open(os.path.join(output_path,'prediction_C2C.json'), 'w') as outfile:
        json.dump(pred_dict_c2c, outfile)
    t_end = time.time()
    t_all_end = time.time()
    logger.info(f"Processing time C2C: {t_end - t_start}")
    logger.info(f"Processing time ALL: {t_all_end - t_all_start}")
    logger.info(f"End of predicting")
